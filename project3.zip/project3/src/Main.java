import java.util.Scanner;

public class Main {
    public static void main(String[] args) {
        //Değişkenleri oluştur
        int mat,fizik,kimya,turkce,tarih,muzik,score,limit;
        limit=50;

        //Scanner sınıfını tamamladık
        Scanner input= new Scanner(System.in);

        //kullanıcıdan değerleri al
        System.out.print("Matematik Notunuz:");
        mat=input.nextInt();

        System.out.print("Fizik notunuz:");
        fizik=input.nextInt();

        System.out.print("kimya notunuz:");
        kimya= input.nextInt();

        System.out.print("Türkçe notunuz");
        turkce= input.nextInt();

        System.out.print("Tarih notunuz:");
        tarih= input.nextInt();

        System.out.print("Muzik notunuz:");
        muzik= input.nextInt();

        score = (mat+fizik+kimya+turkce+tarih+muzik)/6;

        System.out.print("Not Ortalamanız : ");
        System.out.println(score);


        int toplam=(mat+fizik+kimya+turkce+tarih+muzik);
        double sonuc= toplam / 6.0;

        String end = (score>=limit)?"Sınıfı Geçti":"Sınıfta Kaldı";
        System.out.println(end);
    }
}
